m=[]
t=[]
d=[]

for i in range(1):
    r=list(map(int,input().strip().split()))
    p=tuple(map(int,input().strip().split()))


    m.append(r)
    t.append(p)

p={"a":"apple","b":"bat"}

d.append(p)

print(m)
print(t)
print(d)