data=[4,5,104,101,107,180,170, 160, 350,360]

min_val=100
max_val=200

for i in range(len(data)-1,-1,-1):
    if data[i]<=min_val:
        del data[i]

for i in range(len(data)-1,-1,-1):
    if data[i]>=max_val:
        del data[i]

print(data)






