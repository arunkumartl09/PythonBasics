available_parts=["monitor",
                 "keyboard",
                 "mouse",
                "CPU",
                 "Usb"]

current_choice=""

computer_parts=[]

while current_choice!='0':

    if current_choice in "12345":
        print("{}".format(current_choice))

    else:
        print("please provide your option")

    current_choice=input()

    if current_choice=='1':
        computer_parts.append("monitor")
    elif current_choice=='2':
        computer_parts.append("keyboard")

print("you bought these parts {}".format(computer_parts))




