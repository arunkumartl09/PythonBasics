location={0:"sittng in a bus and travelling",
          1:"You are in tumkur",
          2:"you are in Hassan",
          3:"You are in shimoga",
          4:"you are in manglore",
          5:"you are in bengaluru"}

exits=[{"Q":0},
       {"W":2,"N":5,"S":4,"E":3,"Q":0},
       {"N":5,"S":4,"E":1,"Q":0},
       {"W":1,"Q":0},
       {"N":1,"W":2,"Q":0},
       {"S":1,"W":2,"Q":0}
       ]
loc=1
while True:
    available_exits=""

    for direction in exits[loc].keys():
        available_exits+=direction+","

    if loc==0:
        break
    print(location[loc])

    direction=input("Available exits are "+ available_exits)

    if direction in exits[loc]:
        loc=exits[loc][direction]
    else:
        print("you are in wrong direction")


