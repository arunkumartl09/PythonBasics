a=["arun","mahesh","lokesh"]

b=[["arun","mahesh","lokesh"],["vamshi","kumar"]]

h=[]
p=[]
for i in range(2):
    k=list(map(str,(input().strip().split())))
    h.append(tuple(k))

print(h)

w=tuple(h)

print(w)


for i in range(2):
    key=input()
    value=input()

    d=dict(zip([key],[value]))

    print(d)
