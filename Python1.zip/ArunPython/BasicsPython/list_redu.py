
T=[2,34,6,7,8,9,12,3,5,6,7]

print(T)
min_val=5
max_val=40

stop=0
for index, value in enumerate(T):
    if value>=min_val:
        stop=index


    del T[:stop]

print(T)


