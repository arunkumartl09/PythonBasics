sen=input("enter the sentence")


sep=""
for ch in sen:
    if ch.isalpha():
        sep+=ch


rev=sep[::-1]

if rev.casefold()==sep.casefold():
    print("it is a palindrome")
else:
    print("it is not a palindrome")