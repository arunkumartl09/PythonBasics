fruit={"apple":"good for health",
       "lemon":"it is little bit sour",
       "orrange":"it is of sytric acid",
       "pineapple":"it is good for eyes"
       }



print(fruit.keys())

print(fruit.values())