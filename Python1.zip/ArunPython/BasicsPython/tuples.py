KGF=[("KGF"),
     ("Yash"),
     ("2021")]

Pushpa=(("Pushpa"),
        ("Allu Arjun"),
        ("2022"))

KGF.append("Not this year")

print(KGF)

print(Pushpa)