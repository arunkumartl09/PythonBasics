n=int(input())

a=list(map(int, input().strip().split()))

b_gen=[]
d_min=[]
y_max=[]

for i in range(n):
    c=a[i]
    b_gen.append(c)
    k=min(b_gen)

    w=max(b_gen)

    d_min.append(k)

    y_max.append(w)

r=[]
mnt=0
for i in range(len(d_min)-1):
    if(d_min[i+1]-d_min[i]!=0):
        mnt+=1
        r.append(d_min[i+1])
u=[]
cnt=0
for i in range(len(y_max)-1):
    if(y_max[i+1]-y_max[i]!=0):
        cnt+=1
        u.append(y_max[i+1])

print(d_min)
print(y_max)

print("{} {}".format(cnt,mnt))

