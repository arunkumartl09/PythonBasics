import tkinter

mainwindow=tkinter.Tk()

mainwindow.title("Hello Arun")

mainwindow.geometry('640x480')

button1=tkinter.Button(mainwindow,text="Enter")

button1.pack(side='top', anchor='n')

mainwindow.mainloop()