n=int(input())

a=list(map(int,input().strip().split()))

cnt=0
for i in range(n):
    if a[i]==max(a):
        cnt+=1
print(cnt)

