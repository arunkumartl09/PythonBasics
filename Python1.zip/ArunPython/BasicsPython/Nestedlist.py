menu=[["eggs","chicken","1"],
      ["eggs", "chicken","mutton","fish","2"],
      ["cabage","betroute", "carrot","beans","3"]]

order=input()
for i in range(len(menu)):
    for item in menu[i]:

        if order==item:
           for fud in menu[i]:
               if fud.isalpha():
                   print("{}".format(fud))








