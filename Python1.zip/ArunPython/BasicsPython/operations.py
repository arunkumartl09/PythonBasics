a={1,2,3,4,5,6,7}
b={3,4,5,60,60}

c=a.intersection(b)

d=b.difference(a)

squares={2,4,9,16,81}

squares.discard(4)

squares.remove(16)


print(squares)


persons={"arun","mahesh","lokesh","vamshi","manu"}

coders={"arun","mahesh","manu"}

if persons.issuperset(coders):
    print("true")








