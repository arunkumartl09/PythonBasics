numbers_evn=set(range(0,10,2))
numbers_odd=set(range(0,10,2))

print(numbers_evn)
print(numbers_odd)

even=(0,2,4,6,8)
odd=(1,3,5,7,9)

num=even+odd

numbers=numbers_odd.intersection(numbers_evn)


print(num)

print(numbers)



