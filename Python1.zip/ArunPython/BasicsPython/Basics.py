num1=int(input("enter the first number"))

num2=int(input("enter the second number"))

a="+-*/"



for index in a:
    opt=input("enter the operator")

    if opt=='+':
        print(num1+num2)
    elif opt=='-':
        print(num1-num2)
    elif opt=="*":
        print(num1*num2)
    elif opt=="/":
        print(num1//num2)

