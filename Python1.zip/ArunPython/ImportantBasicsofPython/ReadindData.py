# Reading Data from user for list
data_int=list(map(int,input().strip().split()))
data_str=list(map(str,input().strip().split()))

# data_int reads integer values with spaces and stores them in a list
# data_str reads strings from user with spaces and stores them in a list
# Example of input: 1 2 3 4 5 6=> data_int=[1,2 3,4,5,6]
# Example of string input:arun mahesh manu lokesh vamshi=> data_str=["arun", "mahesh","manu","lokesh","vamshi"]
# List is a mutable object=>we can add or remove data
##########################################################################################################################

#Reading data from user for tuple
data_t=list(input())
data_t=tuple(data_t)

# we cannot "add","remove" to the tuple
# To read from user, first we need to store data in list and convert list into tuple.
# Tuple are used to store data in scured way
# Tuples are immutable objects=> we can't add or remove data
######################################################################################################################

#Reading data from user for dictionary
#01
data_d_key=input()
data_d_value=input()

dictionary={}

dictionary[data_d_key]=data_d_value

#02
data_key=input()
data_value=input()

z=dict(zip([data_key],[data_value]))

# Dictionaries stores data in accordance with the key and respective value
# Dictionaries are mutable objects
#########################################################################################################################

# Reading data from user for set
#01
odd=set()
odd.add(1)
odd.add("arun")

#02
data_set=input()
even=set()
even.add(data_set)

# sets are unordered data
# add and remove methods are used to do add and remove data

#############################################################################################################################
