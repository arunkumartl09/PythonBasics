# Loop operation in list
#01 Forward method using range and len functions
a=list(map(int,input().strip().split())) #Reading input from the user=>1 2 3 4

for i in range(len(a)): # range and len are functions: range gives the value up to and len gives length of a.
    print(a[i])         # prints the values 1 2 3 4.

#02 enumerate function
b=list(map(int,input().strip().split())) # Reading input from the user => 5 6 7 8

for index, value in enumerate(b): # enumerate function gives index and values of corresponding list
    print(value)                  # printing values present in a list

#03 Reverse method using len and range functions
c=list(map(int,input().strip().split())) # Reading input from the user => 9 8 5 6

for i in range(len(c)-1,-1,-1): # len(c)-1 gives number of elements, -1 represents one step , -1 does backward.
    print(i)                    # prints the values as 5 6 8 9

#04 Storing list inside a list
x=[]

for i in range(1):
    y=list(map(int,input().strip().split())) # Reads input 1 2 3 4 and stores in y as [1,2,3,4]
    x.append(y)                              # stores list y inside x as [[1,2,3,4]]

#############################################################################################################################

# Loop operations in tuple
#01 read list and convert into tuple
p=[]
for i in range(1):
    k=list(map(int,input().strip().split())) # Reading values as 4 7 8 9 and stores in k as [4,7,8,9]
    m=tuple(k)                               # converts k list into m tuple (4,7,8,9)
    p.append(m)                              # stores a tuple into a p list as [(4,7,8,9)]
    w=tuple(p)                               # converts p list into w tuple ad ((4,7,8,9))

########################################################################################################################

# Loop operation in dictionary
#01
r={}                    # empty dictionary
for i in range(1):      # one dictionary
    key=input()         # reading key value
    data=input()        # reading data value
    r[key]=data         # storing into a dictionary

#02
for i in range(1):             # reads one dictionary
    key=input()                # reading key value
    data=input()               # reading data value
    g=dict(zip([key],[data]))  # zip is functions that maps keys and data ina g dictionary

############################################################################################################################

# Loop Operations for set
#01
g=set()                # assigning g as a empty set

for i in range(1):     # reading one value at a time
    p=input()          # reading input from user
    g.add(p)           # stroing in set








