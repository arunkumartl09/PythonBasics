#01 storing a list inside a list
n=int(input())                      # number of times
p=[]
for i in range(n):
    k=list(map(int,input().strip().split()))    # reading user input 1 2 3 4 and storing values in a list k as [1,2,3,4]
    p.append(k)                                 # stores k list in a p list as [[1,2,3,4]]

########################################################################################################################
#02 (01) storing tuple inside a list
n=int(input())               # number of times

p=[]
for i in range(n):
    k=list(map(int,input().strip().split()))    # reading user input 1 2 3 4 and storing values in a list k as [1,2,3,4]
    g=tuple(k)                                  # converts k list into g tuple as (1,2,3,4)
    p.append(g)                                 # stores g tuple inside a p list as [(1,2,3,4)]

#02 (02)
n=int(input())
g=[]
for i in range(n):
    k=tuple(map(int,input().strip().split()))   # mapping string values integer in a tuple

    g.append(k)                                 # storing tuple in a list

#######################################################################################################################
#03 (01) storing a dictionary inside a list
n=int(input())               # reading n

d={}                         # assigning empty dictionary to d
p=[]                         # assigning empty list to a p
for i in range(n):           #upto n entries
    key=input()              # read key value
    data=input()             # read data value
    d[key]=data              # store in a dictionary  {1:"arun,2:"kumar}
p.append(d)                  # storing dictionary inside a list outside of the loop [{1:"arun,2:"kumar"}]

#03 (02)
n=int(input())                         #read n entries

p=[]                                   # assigning empty list to a p
for i in range(n):
    key=input()                        # read key value
    data=input()                       # read data value
    d=dict(zip([key],[data]))          # store key and data in a dictionary
    p.append(d)                        # storing dictionary inside a list inside of the loop

###########################################################################################################################

#04 storing a set inside list
n=int(input())
g=[]
for i in range(n):
    k=set(map(int,input().strip().split()))       # mapping string values as integer in a set k=>{3,4,5,6}

    g.append(k)                                   # storing a set inside a list =>[{3,4,5,6}]

##############################################################################################################################

#05 storing tuple inside a tuple
n=int(input())

g=[]
for i in range(n):
    k=tuple(map(int,input().strip().split()))   # storing values 1 2 3 4=>(1,2,3,4)
    g.append(k)                                 # stores a tuple k in list g => [(1,2,3,4)]
    m=tuple(g)                                  # converts list g into a tuple m=>((1,2,3,4))

###########################################################################################################################

#06 stoing list inside a tuple
n=int(input())

for i in range(n):
    k=tuple(map(int,input().strip().split()))  #reads 1 2 3 4 and stores in k as =>(1,2,3,4)
    g.append(list(k))                          # converts tuple k into list and stores in a list g=>[[1,2,3,4]]
    m=tuple(g)                                 # converts list g into a tuple => ([1,2,3,4])

###################################################################################################################################

#07 storing a set inside a tuple
n=int(input())
g=[]
for i in range(n):
    k=set(map(int,input().strip().split()))    # reads 1 2 3 4 and stores in a set=>{1,2,3,4}
    g.append(k)                                # stores in a list g as =>[{1,2,3,4}]
    h=tuple(g)                                 # converts list g into a tuple=>({1,2,3,4})

##################################################################################################################################
